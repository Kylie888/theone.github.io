import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { Toaster } from '@/components/ui/toaster';
import { useToast } from '@/components/ui/use-toast';

const Typewriter = ({ text, speed = 50, onComplete }) => {
  const [displayedText, setDisplayedText] = useState('');

  useEffect(() => {
    let i = 0;
    const intervalId = setInterval(() => {
      setDisplayedText(text.substring(0, i + 1));
      i++;
      if (i > text.length) {
        clearInterval(intervalId);
        if (onComplete) onComplete();
      }
    }, speed);

    return () => clearInterval(intervalId);
  }, [text, speed, onComplete]);

  return <>{displayedText}</>;
};

const images = [
  "https://storage.googleapis.com/hostinger-horizons-assets-prod/4e77ef29-1c24-4900-ae66-d56c08243aec/439a9db69a2ef308542c60a3819e74c2.jpg",
  "https://storage.googleapis.com/hostinger-horizons-assets-prod/4e77ef29-1c24-4900-ae66-d56c08243aec/dcef2d322026b09e7d5fb26a989f53d2.jpg",
  "https://storage.googleapis.com/hostinger-horizons-assets-prod/4e77ef29-1c24-4900-ae66-d56c08243aec/297698d60c5a8137491d5587bf6458fe.jpg",
  "https://storage.googleapis.com/hostinger-horizons-assets-prod/4e77ef29-1c24-4900-ae66-d56c08243aec/b0efe246f539927ace1203af3127bff0.jpg",
  "https://storage.googleapis.com/hostinger-horizons-assets-prod/4e77ef29-1c24-4900-ae66-d56c08243aec/6aa65ecaaaaaf2bf339efeb32fa4ff06.jpg",
  "https://storage.googleapis.com/hostinger-horizons-assets-prod/4e77ef29-1c24-4900-ae66-d56c08243aec/7df2450b545c4c117f10b14059e55725.jpg",
  "https://storage.googleapis.com/hostinger-horizons-assets-prod/4e77ef29-1c24-4900-ae66-d56c08243aec/062058bc6e3a1851bafad79cefb55a90.jpg"
];

function App() {
  const [currentFlow, setCurrentFlow] = useState('password');
  const [password, setPassword] = useState('');
  const [isEnvelopeOpen, setIsEnvelopeOpen] = useState(false);
  const [playMusic, setPlayMusic] = useState(true);
  const [isTypewriterComplete, setIsTypewriterComplete] = useState(false);
  const [showSlideshow, setShowSlideshow] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const { toast } = useToast();

  const correctPassword = '100625';

  useEffect(() => {
    if (isTypewriterComplete) {
      const timer = setTimeout(() => {
        setShowSlideshow(true);
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [isTypewriterComplete]);

  useEffect(() => {
    if (showSlideshow) {
      const interval = setInterval(() => {
        setCurrentImageIndex(prevIndex => (prevIndex + 1) % images.length);
      }, 3000);
      return () => clearInterval(interval);
    }
  }, [showSlideshow]);

  const handleNumberPress = (number) => {
    if (password.length < 6) {
      setPassword(prev => prev + number);
    }
  };

  const handlePasswordSubmit = () => {
    if (password === correctPassword) {
      setCurrentFlow('success');
      setTimeout(() => {
        setCurrentFlow('letter');
      }, 6000);
    } else {
      toast({
        title: "Sai mật khẩu rồi nhé hẹ hẹ",
        duration: 3000,
      });
      setPassword('');
    }
  };

  const handleEnvelopeClick = () => {
    setIsEnvelopeOpen(true);
  };

  const createFireworks = () => {
    const fireworks = [];
    for (let i = 0; i < 20; i++) {
      fireworks.push(
        <div
          key={i}
          className="firework"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            background: `hsl(${Math.random() * 360}, 70%, 60%)`,
            animationDelay: `${Math.random() * 2}s`,
          }}
        />
      );
    }
    return fireworks;
  };

  const createStars = () => {
    const stars = [];
    for (let i = 0; i < 15; i++) {
      stars.push(
        <div
          key={i}
          className="star"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            animationDelay: `${Math.random() * 2}s`,
          }}
        />
      );
    }
    return stars;
  };

  const renderPasswordFlow = () => (
    <div className="min-h-screen bg-gradient-to-br from-pink-400 via-pink-500 to-pink-600 flex flex-col items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-8"
      >
        <h1 className="text-4xl font-bold text-white mb-6">
          Truy tìm kho báu nàooo
        </h1>
      </motion.div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3 }}
        className="mb-8"
      >
        <div className="flex space-x-3 mb-8">
          {[...Array(6)].map((_, index) => (
            <div
              key={index}
              className={`password-dot ${index < password.length ? 'filled' : ''}`}
            />
          ))}
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.5 }}
        className="grid grid-cols-3 gap-4 mb-8"
      >
        {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((number) => (
          <button
            key={number}
            onClick={() => handleNumberPress(number.toString())}
            className="keypad-button"
          >
            {number}
          </button>
        ))}
        <div></div>
        <button
          onClick={() => handleNumberPress('0')}
          className="keypad-button"
        >
          0
        </button>
        <button
          onClick={() => setPassword(prev => prev.slice(0, -1))}
          className="keypad-button text-lg"
        >
          ⌫
        </button>
      </motion.div>

      {password.length === 6 && (
        <motion.button
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          onClick={handlePasswordSubmit}
          className="bg-white text-pink-500 px-8 py-3 rounded-full font-bold text-lg hover:bg-pink-50 transition-all duration-300 pulse"
        >
          Mở khóa
        </motion.button>
      )}
    </div>
  );

  const renderSuccessFlow = () => (
    <div className="min-h-screen bg-gradient-to-br from-purple-400 via-pink-500 to-yellow-500 flex flex-col items-center justify-center p-4 relative overflow-hidden">
      {createFireworks()}
      {createStars()}
      
      <motion.div
        initial={{ opacity: 0, scale: 0.5 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.8 }}
        className="text-center z-10"
      >
        <img 
          src="https://storage.googleapis.com/hostinger-horizons-assets-prod/4e77ef29-1c24-4900-ae66-d56c08243aec/cbd59566db59d657b5f3ca9e356adfe4.jpg" 
          alt="Hình ảnh 100" 
          className="w-48 h-64 mx-auto mb-6 rounded-[50%] object-cover"
        />
        <h1 className="text-3xl font-bold text-white fade-in-up">
          Kui thật là thông minh mòoo
        </h1>
      </motion.div>
    </div>
  );

  const letterText = "/Vuốt xuống để đọc hết ạ : >/\n\nHí hí đấu trí vậy thôi 🤣🤣 Chứ bé hem có chuẩn bị được gì cả í hẹ hẹ 🤧🤧 Chỉ là muốn chúc cho người đàn ông cực phẩm của em một buổi sáng tỉnh táo, tự tin và đạp bay mọi vấn đề nhé. 💋😚💪\n\nIem biết mấy hôm vừa rồi mọi thứ như đổ dồn lại khiến Kui mệt đứ đừ mà, và hôm nay có thể sẽ nhiều việc, nhưng nếu ai vượt qua được thì chắc chắn chỉ có thể là Kui thôi – vì Kui giỏi, thông minh, cực bảnhhhh 👅👅 (đàn anh của Khá Bảnh luôn ạ) và… lỡ tuyệt vời quá mức cần thiết 🥹\n\nNên là, làm việc giỏi thôi, đừng giỏi thêm nữa – em nghiện anh quá lắm rồi í ạ 🫶\n\nCó một sự thật cần ghi nhớ: Anh là điều tuyệt nhất mà em trân quý mỗi ngày. Anh chính là kho báu mà em truy tìm đấy hẹ hẹ. Love you Bae 💗💞";

  const renderLetterFlow = () => (
    <div className="min-h-screen bg-gradient-to-br from-pink-200 via-pink-300 to-pink-400 flex flex-col items-center justify-center p-4">
      <AnimatePresence>
        {currentFlow === 'letter' && !showSlideshow && (
          <>
            <motion.img
              initial={{ opacity: 1, scale: 1 }}
              animate={{ opacity: 0, scale: 0.8 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 7 }}
              src="https://storage.googleapis.com/hostinger-horizons-assets-prod/4e77ef29-1c24-4900-ae66-d56c08243aec/82f95697379bdd930780461626ed6bbc.jpg"
              alt="Hình ảnh thu"
              className="w-32 h-32 rounded-full object-cover mb-8 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2"
            />
            
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 7.5, duration: 0.8 }}
              className={`envelope ${isEnvelopeOpen ? 'opened' : ''}`}
              onClick={handleEnvelopeClick}
            >
              <div className="envelope-flap"></div>
              <div className="letter georgia-font">
                <div className="text-pink-800 text-sm leading-relaxed whitespace-pre-wrap">
                  {isEnvelopeOpen && <Typewriter text={letterText} speed={50} onComplete={() => setIsTypewriterComplete(true)} />}
                </div>
              </div>
            </motion.div>

            {!isEnvelopeOpen && (
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 8 }}
                className="text-pink-700 mt-4 text-center font-medium"
              >
                Nhấn vào bức thư để mở nhé! 💌
              </motion.p>
            )}
          </>
        )}
      </AnimatePresence>
      {showSlideshow && (
        <div className="w-full h-full flex items-center justify-center">
            <AnimatePresence mode="wait">
                <motion.img
                    key={currentImageIndex}
                    src={images[currentImageIndex]}
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.8 }}
                    transition={{ duration: 1 }}
                    className="max-w-[90vw] max-h-[90vh] object-contain rounded-lg shadow-2xl"
                />
            </AnimatePresence>
        </div>
      )}
    </div>
  );

  return (
    <>
      <Helmet>
        <title>Truy Tìm Kho Báu</title>
        <meta name="description" content="Một cuộc phiêu lưu tìm kiếm kho báu đầy bất ngờ" />
      </Helmet>
      
      {playMusic && (
        <iframe 
          src="https://www.nhaccuatui.com/mh/auto/T2YhxWx8R7gx" 
          width="1" 
          height="1" 
          frameBorder="0" 
          allow="autoplay"
          style={{ display: 'none' }}
        ></iframe>
      )}

      <AnimatePresence mode="wait">
        {currentFlow === 'password' && (
          <motion.div
            key="password"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
          >
            {renderPasswordFlow()}
          </motion.div>
        )}
        
        {currentFlow === 'success' && (
          <motion.div
            key="success"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
          >
            {renderSuccessFlow()}
          </motion.div>
        )}
        
        {currentFlow === 'letter' && (
          <motion.div
            key="letter"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
          >
            {renderLetterFlow()}
          </motion.div>
        )}
      </AnimatePresence>
      
      <Toaster />
    </>
  );
}

export default App;